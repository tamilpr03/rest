<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// get database connection
include_once '../config/config.php';
// initiate user object
include_once '../objects/auth.php';

$database = new Config();
$db = $database->getConnection();
$auth = new Auth($db);

$request_method=$_SERVER["REQUEST_METHOD"];

$data = json_decode(file_get_contents("php://input"));

switch($request_method)
    {
      case 'GET':
          //CERATE set property values
          $auth->user_name = $data->user_name;
          $auth->user_password = $data->user_password;
          //$user->user_name = $_GET["user_name"];
          //$user->user_password = $_GET["user_password"];
          $result = $auth->login();
          if($result->num_rows>0){
          	while ($row = $result->fetch_array()){
          		$result_array[] = array(
          				"status"=>true,
          				"user_name"=>$row["user_name"],
          				"user_code" => $row["user_code"],
          				"message" => "Login successfull"
          		);
          	}
          }else{
            $result_array[] = array(
          		"status"=>false,
          		"message" => "Invalid credential"
            );
          }
          header('Content-Type: application/json');
          echo json_encode($result_array);
      break;
      case 'POST':
          // set property values
          $auth->user_code = $data->user_code;
          $auth->user_name = $data->user_name;
          $auth->user_password = $data->user_password;
          //$user->user_code = $_GET["user_code"];
          //$user->user_name = $_GET["user_name"];
          //$user->user_password = $_GET["user_password"];
          $result = $auth->signup();
          // create the product
          if($result){
            $result_array = array(
          		"status"=>true,
          		"message" => "Register successfull"
            );
          }
          else{
              $result_array = array(
            		"status"=>false,
            		"message" => "username already exists"
              );
          }
          header('Content-Type: application/json');
          echo json_encode($result_array);
    break;
    case 'PUT':

    break;
    case 'DELETE':

    break;
    default:
      // Invalid Request Method
      header("HTTP/1.0 405 Method Not Allowed");
      echo json_encode('Wrong Method, Not Allowed..');
    break;
    }
?>
