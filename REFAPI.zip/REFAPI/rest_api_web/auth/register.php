<?php
// get database connection
include_once '../config/config.php';
// initiate product object
include_once '../objects/auth.php';

$database = new Config();
$db = $database->getConnection();
$auth = new Auth($db);
// get posted data
$data = json_decode(file_get_contents("php://input"));
// set product property values
$auth->user_code = $data->user_code;
$auth->user_name = $data->user_name;
$auth->user_password = $data->user_password;
//$user->user_code = $_GET["user_code"];
//$user->user_name = $_GET["user_name"];
//$user->user_password = $_GET["user_password"];
$result = $auth->signup();
// create the product
if($result){
  $result_array = array(
		"status"=>true,
		"message" => "Register successfull"
  );
}
else{
    $result_array = array(
		"status"=>false,
		"message" => "username already exists"
  );
}
echo json_encode($result_array);
?>
