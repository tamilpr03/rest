<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// get database connection
include_once '../config/config.php';
// initiate user object
include_once '../objects/user.php';
$database = new Config();
$db = $database->getConnection();

$user = new User($db);

$request_method=$_SERVER["REQUEST_METHOD"];
$data = json_decode(file_get_contents("php://input"));
switch($request_method)
  {
    case 'GET':
      // Retrive data
      if(!empty($data->user_code))
          {
            // READ ONE set product property values
            $user->user_code = $data->user_code;
            //interconnect value to object
            $result= $user->readone();
            // create output
            if ($result->num_rows > 0){
            	  while ($row = $result->fetch_array()){
            		//$result_array[]=$row;

                $result_array []=array(
                "user_code" => $row['user_code'],
                "user_name" => $row['user_name']
                );

            	}
            } else{
            	$result_array = array(
            		"status"=>false,
            		"message" => "0 records found"
            	);
            }
            header('Content-Type: application/json');
             echo json_encode($result_array);
           }
      else
          {
            $result = $user->readall();
            // create output
             if($result->num_rows > 0) {
            	  while ($row = $result->fetch_array()){
            		$result_array[]=$row;
                //$result_array[]=array(
                //"user_code" => $user_code,
                //"user_name" => $user_name
                //);
            	 }
            }else {
            		$result_array= array(
            			"status"=>false,
            			"message"=>"0 record found"
            		);
            }
            header('Content-Type: application/json');
            echo json_encode($result_array);
        }
      break;
      case 'POST':
          //CERATE set product property values
          $user->user_code = $data->user_code;
          $user->user_name = $data->user_name;
          // create output
          $result = $user->create();
          if($result){
              $result_array = array(
                "status"=>true,
                "message" => "creates successfully"
              );
          }
          else{
              $result_array = array(
                "status"=>false,
                "message" => "Unable to create"
              );
          }
          header('Content-Type: application/json');
          echo json_encode($result_array);
    break;
    case 'PUT':
          //UPDATE set product property values
          $user->user_code = $data->user_code;
          $user->user_name = $data->user_name;
          // create output
            $result = $user->update();
          if($result){
             $result_array= array(
          		"status"=>true,
          		"message"=>"successfully updated"
          	);
          }else{
              $result_array= array(
            		"status"=>false,
            		"message"=>"unable to update"
            	);
          }
          echo json_encode($result_array);
    break;
    case 'DELETE':
          //DELETE set product property values
          $user->user_code = $data->user_code;
          // craete output
          $result = $user->delete();
          if($result){
          	$result_array= array(
          		"status"=>true,
          		"message"=>"successfully deleted"
          	);
          }
          else{
          	$result_array= array(
          		"status"=>false,
          		"message"=>"unable to delete"
          	);
          }
          echo json_encode($result_array);
    break;
    default:
      // Invaluser_code Request Method
      header("HTTP/1.0 405 Method Not Allowed");
      echo json_encode('Wrong Method, Not Allowed..');
    break;
    }

?>
