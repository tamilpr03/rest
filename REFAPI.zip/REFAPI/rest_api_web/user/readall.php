<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// get database connection
include_once '../config/config.php';

// initiate user object
include_once '../objects/user.php';

$database = new Config();
$db = $database->getConnection();

$user = new User($db);

$result = $user->readall();

 if ($result->num_rows > 0) {
	 while ($row = $result->fetch_array()){
		$result_array[]= array(
			"status"=>true,
      "user_code"=>$row["user_code"],
			"user_name"=>$row["user_name"]
		);
	 }
 } else {
		$result_array[]= array(
			"status"=>false,
			"message"=>"0 record found"
		);
}
 echo json_encode($result_array);
?>
