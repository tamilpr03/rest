<?php
class Config{

    // specify your own database credentials
    private $host = "localhost";
    private $db_name = "rest_api_mobile";
    private $username = "root";
    private $password = "";
    public $con;

    // get the database connection
    public function getConnection(){
		$this->con = new mysqli($this->host, $this->username, $this->password, $this->db_name);

		if ($this->con->connect_error) {
			$connection = $this->con->connect_error;
			$result_array=array(
				"problem"=>"database  not connected",
				"connnection failed"=>$connection
			);
			$result = json_encode($result_array);

			die($result);

			return false;
		}else{

			return $this->con;
		}
    }

}

?>
