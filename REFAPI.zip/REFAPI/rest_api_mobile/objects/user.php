<?php
class User{
    // database connection and table name
    private $con;
    private $table_name = "user";
    // object properties
    public $user_code;
  	public $user_name;

    // constructor with $db as database connection
    public function __construct($db){
        $this->con = $db;
    }
// create user
function create(){
  // query to insert user
  $sql = "INSERT INTO " . $this->table_name . " (user_code,user_name) VALUES ('$this->user_code','$this->user_name')";
  // prepare query
  $result = $this->con->query($sql);
  if($result==true){
    return true;
  }else {
    return false;
  }
}
//read all records
function readall(){
    // query to insert user
    $sql = "SELECT * FROM " . $this->table_name . "";
    // prepare query
    $result = $this->con->query($sql);
    if($result==true){
      return $result;
    }else {
      return false;
    }
}
//read one user
function readOne(){
    // query to insert user
  	$sql = "SELECT * FROM " . $this->table_name . " WHERE user_code = '$this->user_code' ";
  	// prepare query
    $result = $this->con->query($sql);
    if($result==true){
      return $result;
    }else {
      return false;
    }
}
//delete one user
function delete(){
  	$sql = "DELETE FROM " . $this->table_name . " WHERE user_code='$this->user_code'";
  	// prepare query
  	$result = $this->con->query($sql);
    if($result==true){
      return true;
    }else {
      return false;
    }
}
//update one records
function update(){
    // query to insert user
	  $sql = "UPDATE " . $this->table_name . " SET user_code='$this->user_code',user_name='$this->user_name' WHERE user_code='$this->user_code'";
	  // prepare query
    $result = $this->con->query($sql);
    if($result==true){
      return true;
    }else {
      return false;
    }
}
}
