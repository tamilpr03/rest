<?php
class Auth{
  // database conection and table name
  private $con;
  private $table_name = "user";
  // object properties
	public $user_name;
	public $user_password;
	public $user_code;
  // constructor with $db
  public function __construct($db){
    $this->con = $db;
  }
  //sign up user
  function signup(){
    if($this->isAlreadyExist()){
      return false;
    }
    // query to insert record
    $sql = "INSERT INTO " . $this->table_name . " (user_name,user_password,User_code) VALUES ('$this->user_name','$this->user_password','$this->user_code')";
    // prepare query
    $result = $this->con->query($sql);
      return true;
  }
  //login user
  function login(){
  	$sql = "SELECT * FROM " . $this->table_name . " WHERE user_name='".$this->user_name."' AND user_password='".$this->user_password."'";
  	$result = $this->con->query($sql);
    if($result){
  	   return $result;
    }else {
      return false;
    }
  }
  // Exist user
  function isAlreadyExist(){
  	$sql = "SELECT * FROM " . $this->table_name . " WHERE user_name='$this->user_name'";
  	$result = $this->con->query($sql);
  	if($result->num_rows){
  	   return true;
    }
    else{
      return false;
    }
  }
}
