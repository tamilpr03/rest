<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "core_php_api";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"));
//initiate input
$code = $data->code;
$action=$data->action;
$quantity=$data->quantity;
//input feilds
//$code=$_GET["code"];
//$action=$_GET["action"];
//$quantity=$_GET["quantity"];

//add to cart start
if(!empty($action)) {
switch($action) {
	case "add":
		if(!empty($quantity)) {
			//$productByCode = $db_handle->runQuery("SELECT * FROM tblproduct WHERE code='" . $_GET["code"] . "'");
			$sql = "SELECT * FROM tblproduct WHERE code='$code'";
			$result = $conn->query($sql);
			 // output data of each row
			$productByCode = $result->fetch_assoc();
			$itemArray = array($productByCode["code"]=>array('name'=>$productByCode["name"],
														'code'=>$productByCode["code"],
														'quantity'=>$quantity,
														'price'=>$productByCode["price"],
														'image'=>$productByCode["image"]));

			if(!empty($_SESSION["cart_item"])) {
				if(in_array($productByCode["code"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
						if($productByCode["code"] == $k) {
							if(empty($_SESSION["cart_item"][$k]["quantity"])) {
								$_SESSION["cart_item"][$k]["quantity"] = 0;
							}
							$_SESSION["cart_item"][$k]["quantity"] += $quantity;
						}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;

			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
				if($code == $k)
					unset($_SESSION["cart_item"][$k]);
				if(empty($_SESSION["cart_item"]))
					unset($_SESSION["cart_item"]);
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;
}
}

//output


	if(isset($_SESSION["cart_item"])){
		$products_arr=array();
		$products_arr["records"]=array();
		//$hell=$_SESSION["cart_item"][$k]["code"];

		foreach ($_SESSION["cart_item"] as $item){
			$cart_item=array(
				"image" => $item["image"],
				"name" => $item["name"],
				"code" => $item["code"],
				"price" => $item["price"],
				"quantity" => $item["quantity"]
			);
			array_push($products_arr["records"], $cart_item);
		}
	}else{
		$cart_item=array(
				"message" => "no item found"
			);
	}
// make it json format
print_r(json_encode($products_arr));
//echo $hell;

?>
