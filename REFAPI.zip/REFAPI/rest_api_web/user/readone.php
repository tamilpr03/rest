<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// get database connection
include_once '../config/config.php';
// initiate user object
include_once '../objects/user.php';

$database = new Config();
$db = $database->getConnection();
$user = new User($db);
//initiate input
$data = json_decode(file_get_contents("php://input"));
$user->user_code = $data->user_code;
//$user->user_code = $_GET["user_code"];
$result= $user->readone();

if($result->num_rows > 0){
	while ($row = $result->fetch_array()){
	$result_array[] = array(
		"status"=>true,
		"user_name" => $row["user_name"],
		"user_code" => $row["user_code"]
	);
	}
}else{
	// output data of each row create array
	$result_array[] = array(
		"status"=>false,
		"message" => "0 record found"
	);
}
// make it json format
print_r(json_encode($result_array));


?>
